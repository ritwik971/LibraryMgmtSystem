from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    path('issue/', views.book_issue),
    path('return/', views.book_return),
    path('return/search/<int:library_id>', views.book_return_search)
]
