from django.shortcuts import render
from django.http import HttpResponse, JsonResponse
from datetime import datetime
from .models import *

# Create your views here.
def home(request):
    return render(request,'index.html')

def book_issue(request):
    if request.method == 'POST':
        library_id = int(request.POST['library_id'])
        book_id = int(request.POST['book_id'])
        
        try:
            member = Member.objects.get(library_id = library_id)
        except Member.DoesNotExist: return render(request, 'book_issue.html', {'invalid_member': True})

        try:
            book = Book.objects.get(book_id = book_id)
            if book.quantity == 0: return render(request, 'book_issue.html', {'Book_Not_Available': True})
        except Book.DoesNotExist: return render(request, 'book_issue.html', {'invalid_book': True})

        return_date_str = request.POST['return_date']
        return_date = datetime.strptime(return_date_str, '%Y-%m-%d').date()

        try:
            book_issued = IssuedBook.objects.create(book_id = book, library_id = member, return_date = return_date)
        except ValidationError as e:
             return render(request, 'book_issue.html', {'Max_Due_Reached': True})

        member.total_due += book_issued.rent
        member.save()
        book.quantity -=1
        book.save()
        return render(request, 'book_issue.html', {'success': True})

    return render(request,'book_issue.html')

def book_return_search(request,library_id):

    if request.method == 'POST':
        unique_identifier = str(request.POST.get('unique_identifier'))
        print(unique_identifier)
        issued_book_obj = IssuedBook.objects.get(unique_identifier = unique_identifier)
        print(issued_book_obj.rent)
        return JsonResponse({'totalRentFee': issued_book_obj.rent})
    
    issued_book_objs = IssuedBook.objects.filter(library_id = library_id)
    issued_books = [book_obj.book_id.book_id for book_obj in issued_book_objs]
    book_objs = Book.objects.filter(book_id__in=issued_books)

    book_list = []
    for book in book_objs:
        book_list.append({
                'book_id': book.book_id,
                'book_title': book.title,
                'book_author': book.authors,
                'book_isbn': book.isbn
            })
        
    if not book_list:
        # No books found, return a JsonResponse with an empty list
        return JsonResponse({'books': []}) 
    return JsonResponse({'books': book_list})

def book_return(request):
    if request.method == 'POST':
        unique_identifier = str(request.POST.get('unique_identifier'))
        print(unique_identifier)
        issued_book_obj = IssuedBook.objects.get(unique_identifier = unique_identifier)
        print(issued_book_obj.rent)
        selected_member = issued_book_obj.library_id
        selected_book = issued_book_obj.book_id

        selected_member.total_due -= issued_book_obj.rent
        selected_member.save()

        selected_book.quantity +=1
        selected_book.save()
        issued_book_obj.delete()
        return JsonResponse({'message':'Book Returned Successfully'})

    return render(request,'book_return.html')
