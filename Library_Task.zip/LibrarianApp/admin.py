from django.contrib import admin
from .models import *

# Register your models here

# admin.site.register(Member)
# admin.site.register(Book)

@admin.register(Member)
class MemberAdmin(admin.ModelAdmin):
    list_display = ('library_id', 'name', 'email', 'total_due')

@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('book_id', 'title', 'authors', 'isbn', 'publisher', 'quantity')

@admin.register(IssuedBook)
class IssuedBookAdmin(admin.ModelAdmin):
    list_display = ('book_id', 'library_id', 'issue_date', 'return_date', 'rent')
    search_fields = ('book__title', 'member__name')
    
    def has_add_permission(self, request):
        return False