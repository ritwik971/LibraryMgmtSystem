from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone

# Create your models here.
class Member(models.Model):
    library_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    total_due = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.name
    

class Book(models.Model):
    book_id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100, unique=True)
    authors = models.CharField(max_length=100)
    isbn = models.CharField(max_length=13, unique=True)
    publisher = models.CharField(max_length=255)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return self.title


class IssuedBook(models.Model):
    book_id = models.ForeignKey('Book', on_delete=models.CASCADE)
    library_id = models.ForeignKey('Member', on_delete=models.CASCADE)
    issue_date = timezone.now().date()
    return_date = models.DateField()
    unique_identifier = models.CharField(max_length=155, unique=True, editable=False)
    rent = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)

    class Meta:
        unique_together = ('book_id', 'library_id')

    def clean(self):
        days_issued = (self.return_date - self.issue_date).days
        self.rent = days_issued * 10
        if (self.rent+self.library_id.total_due)>500:
            raise ValidationError('Due Amount Exceeds')
        self.unique_identifier = f"{self.book_id.book_id}_{self.library_id.library_id}"

    def save(self, *args, **kwargs):
        self.clean()
        super().save(*args, **kwargs)

    def __str__(self):
        return f'{self.book_id.title} - {self.library_id.name}'